###################
# Sección de datos
.data
_a:
.word 0
_b:
.word 0
_c:
.word 0
$str0:
.asciiz "Test 1\n"
$str1:
.asciiz "Fin test1\n"

###############
#Seccion de codigo
.text
.globl main
main:
li $t0,3
sw $t0,_b
li $t0,0
sw $t0,_c
li $v0,4
la $a0,$str0
syscall
li $t0,1
lw $t1,_b
add $t0,$t0,$t1
sw $t0,_a
li $v0,5
syscall
sw $v0,_a
li $v0,4
la $a0,$str1
syscall

li $v0, 10
syscall