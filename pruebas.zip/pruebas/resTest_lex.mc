Error Lexico: Error, linea 8: el numero es mayor que 2^31
Error Lexico: Error, linea 11: longitud de la cadena mayor que 16
Error Semantico: Variable _123456789012345678 no declarada
Error Lexico: Error en carácter #@$%& en la linea 14
Error sintactico: Error en la linea 14
